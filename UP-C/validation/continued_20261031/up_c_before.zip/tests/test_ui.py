"""Isolated synthetic UI smoke test; no physical COM connection or saved readings."""
import sys
from pathlib import Path
import time
import unittest
from unittest.mock import patch
import tempfile
import csv

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from emergency_system import EmergencySystem, BoardStatus


class UiTests(unittest.TestCase):
    def test_states_ranges_and_exports(self):
        app = EmergencySystem()
        app.withdraw()
        errors = []
        app.report_callback_exception = lambda *args: errors.append(args)
        try:
            now = time.time()
            s = BoardStatus(protocol=2, light_raw=50000, sound_level=1800, light_online=True,
                            sound_alarm=True, collision_alarm=True, received_at=now)
            app.update_status(s)
            self.assertEqual(app.light_gauge.value, 50000)
            self.assertEqual(app.sound_gauge.value, 1800)
            self.assertEqual(app.alarm_value.cget("text"), "车辆碰撞报警")
            s.collision_alarm = False
            app.update_status(s)
            self.assertEqual(app.alarm_value.cget("text"), "声音超阈值")
            app.toggle_chart()
            size = len(app.chart.samples)
            app.update_status(s)
            self.assertEqual(len(app.chart.samples), size)
            app.toggle_chart()
            s.sound_alarm=False; s.light_online=False
            app.update_status(s)
            self.assertIsNone(app.light_gauge.value)
            self.assertEqual(app.alarm_value.cget("text"), "光照传感器离线")
            # Exercise charts containing offline gaps and values above old UI caps.
            for i in range(20): app.chart.append(None if i % 3 == 0 else 50000, 1800, now+i)
            app.show_unavailable("synthetic test disconnected")
            self.assertTrue(app.stale)
            self.assertIsNone(app.sound_gauge.value)
            with tempfile.TemporaryDirectory(prefix="emergency_synthetic_test_") as directory:
                target = str(Path(directory)/"synthetic.csv")
                with patch("emergency_system.filedialog.asksaveasfilename", return_value=target):
                    app.export_csv()
                with open(target, encoding="utf-8-sig") as handle:
                    rows = list(csv.DictReader(handle))
                    self.assertEqual(rows[0]["光照原始值"], "50000")
                with patch("emergency_system.filedialog.asksaveasfilename", return_value=target):
                    app.toggle_recording()
                app.update_status(s)
                app.stop_recording()
                with open(target, encoding="utf-8-sig") as handle:
                    self.assertEqual(len(list(csv.DictReader(handle))), 1)
            app.update_idletasks()
            self.assertFalse(errors, errors)
        finally:
            app.on_close()


if __name__ == "__main__": unittest.main()
