@echo off
cd /d "%~dp0"
python -c "import tkinter, serial" >nul 2>&1
if errorlevel 1 (
    echo Python, Tkinter or pyserial is missing.
    echo Run: python -m pip install -r requirements.txt
    pause
    exit /b 1
)
python emergency_system.py
if errorlevel 1 pause
