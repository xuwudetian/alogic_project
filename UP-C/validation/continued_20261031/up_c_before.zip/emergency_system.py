"""应急系统：A 工程光照、声音和报警状态监测上位机。"""
from __future__ import annotations

import csv
from collections import deque
import json
import time
import math
from datetime import datetime
import queue
from pathlib import Path
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from serial_protocol import BoardStatus, EmergencySerial

BG = "#08111f"
PANEL = "#101d30"
PANEL2 = "#14253b"
LINE = "#263b59"
TEXT = "#e8f1ff"
MUTED = "#8ea6c3"
CYAN = "#42d9ff"
GREEN = "#35e0a1"
YELLOW = "#ffd166"
RED = "#ff5577"


class Gauge(tk.Canvas):
    def __init__(self, master, title, accent, maximum, **kwargs):
        super().__init__(master, bg=PANEL, highlightthickness=0, **kwargs)
        self.title, self.accent, self.maximum = title, accent, maximum
        self.value, self.unit = 0, ""
        self.bind("<Configure>", lambda _e: self.redraw())

    def set_value(self, value, unit=""):
        self.value = None if value is None else max(0, int(value))
        self.unit = unit
        self.redraw()

    def redraw(self):
        self.delete("all")
        width = max(220, self.winfo_width())
        height = max(120, self.winfo_height())
        self.create_text(16, 16, anchor="w", text=self.title, fill=MUTED,
                         font=("Microsoft YaHei UI", 10, "bold"))
        self.create_text(16, 47, anchor="w", text="—" if self.value is None else f"{self.value:,}", fill=TEXT,
                         font=("Segoe UI", 25, "bold"))
        self.create_text(16, 78, anchor="w", text=self.unit, fill=MUTED,
                         font=("Microsoft YaHei UI", 9))
        left, right, y = 16, width - 16, height - 22
        self.create_rectangle(left, y - 6, right, y + 6, fill="#1d304a", outline="")
        ratio = min(1, (self.value or 0) / max(1, self.maximum))
        self.create_rectangle(left, y - 6, left + (right - left) * ratio, y + 6,
                              fill=self.accent, outline="")


class TrendChart(tk.Canvas):
    def __init__(self, master, **kwargs):
        super().__init__(master, bg=PANEL, highlightthickness=0, **kwargs)
        self.samples = deque(maxlen=240)
        self.bind("<Configure>", lambda _e: self.redraw())

    def append(self, light, sound, timestamp):
        self.samples.append((timestamp, light, sound))
        self.redraw()

    def redraw(self):
        self.delete("all")
        width, height = max(360, self.winfo_width()), max(170, self.winfo_height())
        left, right, top, bottom = 62, width - 54, 45, height - 32
        self.create_text(16, 16, anchor="w", text="实时趋势 · 最近 240 点", fill=TEXT,
                         font=("Microsoft YaHei UI", 11, "bold"))
        self.create_text(right, 16, anchor="e", text="光照（左轴） / 声音（右轴）", fill=MUTED,
                         font=("Microsoft YaHei UI", 9))
        samples = list(self.samples)
        light_max = max(400, *(v[1] or 0 for v in samples)) if samples else 400
        light_max = math.ceil(light_max / 100) * 100
        sound_max = max(1000, *(v[2] for v in samples)) if samples else 1000
        sound_max = math.ceil(sound_max / 500) * 500
        for i in range(5):
            y = top + (bottom - top) * i / 4
            self.create_line(left, y, right, y, fill=LINE)
            self.create_text(left - 8, y, text=f"{light_max * (1 - i / 4):.0f}", fill=CYAN,
                             anchor="e", font=("Segoe UI", 8))
            self.create_text(right + 8, y, text=f"{sound_max * (1 - i / 4):.0f}", fill=YELLOW,
                             anchor="w", font=("Segoe UI", 8))
        y = bottom - (bottom - top) * 700 / sound_max
        self.create_line(left, y, right, y, fill="#785f38", dash=(4, 4))
        self.create_text(left + 6, y - 8, text="声音高阈值 700", fill=YELLOW, anchor="w", font=("Microsoft YaHei UI", 8))
        if len(samples) < 2:
            self.create_text((left + right) / 2, (top + bottom) / 2,
                             text="连接设备后绘制真实采样数据", fill=MUTED, font=("Microsoft YaHei UI", 10))
            return
        start, end = samples[0][0], samples[-1][0]
        for field, scale, color in ((1, light_max, CYAN), (2, sound_max, YELLOW)):
            points = []
            for timestamp, light, sound in samples:
                value = light if field == 1 else sound
                if value is None:
                    if len(points) >= 4: self.create_line(*points, fill=color, width=2)
                    points = []
                    continue
                points.extend((left + (right - left) * (timestamp - start) / max(0.001, end - start),
                               bottom - (bottom - top) * value / scale))
            if len(points) >= 4: self.create_line(*points, fill=color, width=2)
        for x, timestamp, anchor in ((left, start, "w"), (right, end, "e")):
            self.create_text(x, height - 12, text=datetime.fromtimestamp(timestamp).strftime("%H:%M:%S"),
                             fill=MUTED, anchor=anchor, font=("Segoe UI", 8))


class EmergencySystem(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("应急系统")
        self.geometry("1440x900")
        self.minsize(1120, 720)
        self.configure(bg=BG)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.events = queue.Queue()
        self.last_status = None
        self.history = []
        self.csv_rows = deque(maxlen=50000)
        self.event_rows = deque(maxlen=1000)
        self.total_samples = 0
        self.generation = 0
        self.chart_paused = False
        self.stale = True
        self._record_handle = None
        self._record_writer = None
        self.settings_path = Path(__file__).with_name("settings.json")
        self.polling = False
        self.serial = EmergencySerial(on_error=self._enqueue_error)
        self.build_style()
        self.build_ui()
        self.refresh_ports()
        try:
            saved = json.loads(self.settings_path.read_text(encoding="utf-8"))
            if saved.get("port") in self.port_combo["values"]: self.port_var.set(saved["port"])
        except (OSError, ValueError):
            pass
        self.after(100, self.drain_events)
        self.after(500, self.poll_once)

    def build_style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TFrame", background=BG)
        style.configure("TLabel", background=BG, foreground=TEXT, font=("Microsoft YaHei UI", 10))
        style.configure("Muted.TLabel", background=BG, foreground=MUTED, font=("Microsoft YaHei UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=TEXT, font=("Microsoft YaHei UI", 23, "bold"))
        style.configure("Sub.TLabel", background=BG, foreground=MUTED, font=("Microsoft YaHei UI", 10))
        style.configure("Accent.TButton", background=CYAN, foreground="#04101d", borderwidth=0,
                        padding=(12, 7), font=("Microsoft YaHei UI", 9, "bold"))
        style.map("Accent.TButton", background=[("active", "#75e5ff")])
        style.configure("Dark.TButton", background=PANEL2, foreground=TEXT, borderwidth=0,
                        padding=(10, 6), font=("Microsoft YaHei UI", 9))
        style.map("Dark.TButton", background=[("active", "#203956")])
        style.configure("TCombobox", fieldbackground=PANEL2, background=PANEL2, foreground=TEXT, arrowcolor=CYAN)
        style.map("TCombobox", fieldbackground=[("readonly", PANEL2)], foreground=[("readonly", TEXT)],
                  selectbackground=[("readonly", PANEL2)], selectforeground=[("readonly", TEXT)])
        style.configure("Vertical.TScrollbar", background=PANEL2, troughcolor=PANEL, arrowcolor=MUTED,
                        bordercolor=PANEL, lightcolor=PANEL2, darkcolor=PANEL2)
        style.configure("Treeview", background=PANEL, fieldbackground=PANEL, foreground=TEXT,
                        borderwidth=0, rowheight=23, font=("Microsoft YaHei UI", 9))
        style.configure("Treeview.Heading", background=PANEL2, foreground=MUTED, relief="flat",
                        bordercolor=LINE, lightcolor=LINE, darkcolor=LINE, font=("Microsoft YaHei UI", 9, "bold"))

    def panel(self, master):
        return tk.Frame(master, bg=PANEL, highlightbackground=LINE, highlightthickness=1)

    def build_ui(self):
        header = ttk.Frame(self)
        header.pack(fill="x", padx=28, pady=(22, 12))
        ttk.Label(header, text="应急系统", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="A 工程 · 光照与声音实时监测", style="Sub.TLabel").pack(side="left", padx=18, pady=(9, 0))
        self.connection_label = tk.Label(header, text="● 未连接", bg=BG, fg=MUTED,
                                         font=("Microsoft YaHei UI", 10, "bold"))
        self.connection_label.pack(side="right", pady=(8, 0))

        conn = ttk.Frame(self)
        conn.pack(fill="x", padx=28, pady=(0, 14))
        ttk.Label(conn, text="串口", style="Muted.TLabel").pack(side="left")
        self.port_var = tk.StringVar()
        self.port_combo = ttk.Combobox(conn, textvariable=self.port_var, width=15, state="readonly")
        self.port_combo.pack(side="left", padx=8)
        ttk.Label(conn, text="波特率", style="Muted.TLabel").pack(side="left")
        self.baud_var = tk.StringVar(value="115200")
        ttk.Combobox(conn, textvariable=self.baud_var, values=("115200",),
                     width=10, state="readonly").pack(side="left", padx=8)
        ttk.Button(conn, text="刷新端口", style="Dark.TButton", command=self.refresh_ports).pack(side="left", padx=3)
        self.connect_button = ttk.Button(conn, text="连接 A 板", style="Accent.TButton", command=self.toggle_connection)
        self.connect_button.pack(side="left", padx=3)
        ttk.Button(conn, text="导出 CSV", style="Dark.TButton", command=self.export_csv).pack(side="right", padx=3)
        ttk.Button(conn, text="清空日志", style="Dark.TButton", command=self.clear_events).pack(side="right", padx=3)

        root = ttk.Frame(self)
        root.pack(fill="both", expand=True, padx=28, pady=(0, 20))
        root.columnconfigure(0, weight=3, uniform="main")
        root.columnconfigure(1, weight=2, uniform="main")
        root.rowconfigure(1, weight=1)
        root.rowconfigure(2, weight=1)

        cards = ttk.Frame(root)
        cards.grid(row=0, column=0, columnspan=2, sticky="nsew", pady=(0, 12))
        cards.columnconfigure(0, weight=1, uniform="cards")
        cards.columnconfigure(1, weight=1, uniform="cards")
        cards.columnconfigure(2, weight=1, uniform="cards")
        lp, sp, ap = self.panel(cards), self.panel(cards), self.panel(cards)
        lp.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        sp.grid(row=0, column=1, sticky="nsew", padx=8)
        ap.grid(row=0, column=2, sticky="nsew", padx=(8, 0))
        self.light_gauge = Gauge(lp, "环境光照 · 原始值", CYAN, 65535, height=142)
        self.light_gauge.pack(fill="both", expand=True, padx=12, pady=10)
        self.sound_gauge = Gauge(sp, "声音幅度 · ADC 峰峰值", YELLOW, 4095, height=142)
        self.sound_gauge.pack(fill="both", expand=True, padx=12, pady=10)
        self.light_gauge.set_value(None, "等待设备数据")
        self.sound_gauge.set_value(None, "等待设备数据")
        tk.Label(ap, text="安全状态", bg=PANEL, fg=MUTED, font=("Microsoft YaHei UI", 10, "bold")).pack(anchor="w", padx=18, pady=(16, 2))
        self.alarm_value = tk.Label(ap, text="等待数据", bg=PANEL, fg=MUTED, font=("Microsoft YaHei UI", 23, "bold"))
        self.alarm_value.pack(anchor="w", padx=18)
        self.alarm_detail = tk.Label(ap, text="连接 A 板后显示报警来源", bg=PANEL, fg=MUTED, font=("Microsoft YaHei UI", 9))
        self.alarm_detail.pack(anchor="w", padx=18, pady=(2, 0))
        self.alarm_bar = tk.Frame(ap, bg=LINE, height=8)
        self.alarm_bar.pack(fill="x", padx=18, pady=(18, 12))

        chart_panel = self.panel(root)
        chart_panel.grid(row=1, column=0, sticky="nsew", padx=(0, 8), pady=(0, 12))
        chart_panel.rowconfigure(0, weight=1)
        chart_panel.columnconfigure(0, weight=1)
        self.chart = TrendChart(chart_panel)
        self.chart.grid(row=0, column=0, sticky="nsew", padx=8, pady=8)

        snapshot = self.panel(root)
        snapshot.grid(row=1, column=1, sticky="nsew", padx=(8, 0), pady=(0, 12))
        tk.Label(snapshot, text="设备快照", bg=PANEL, fg=TEXT, font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", padx=18, pady=(14, 8))
        self.snapshot_text = tk.Text(snapshot, bg=PANEL, fg=MUTED, relief="flat", height=8, width=36,
                                     font=("Consolas", 10), padx=18, pady=4, state="disabled")
        self.snapshot_text.pack(fill="both", expand=True)

        bottom = ttk.Frame(root)
        bottom.grid(row=2, column=0, columnspan=2, sticky="nsew")
        bottom.rowconfigure(0, weight=1)
        bottom.columnconfigure(0, weight=3, uniform="bottom")
        bottom.columnconfigure(1, weight=2, uniform="bottom")
        events = self.panel(bottom)
        events.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        events.rowconfigure(1, weight=1)
        events.columnconfigure(0, weight=1)
        tk.Label(events, text="事件日志", bg=PANEL, fg=TEXT, font=("Microsoft YaHei UI", 11, "bold")).grid(row=0, column=0, sticky="w", padx=18, pady=(12, 6))
        self.event_tree = ttk.Treeview(events, columns=("time", "level", "message"), show="headings", height=7)
        for col, title, width in (("time", "时间", 86), ("level", "级别", 66), ("message", "信息", 420)):
            self.event_tree.heading(col, text=title)
            self.event_tree.column(col, width=width, anchor="center" if col != "message" else "w")
        self.event_tree.grid(row=1, column=0, sticky="nsew", padx=(10, 0), pady=(0, 10))
        scrollbar = ttk.Scrollbar(events, orient="vertical", command=self.event_tree.yview)
        scrollbar.grid(row=1, column=1, sticky="ns", pady=(0, 10))
        self.event_tree.configure(yscrollcommand=scrollbar.set)
        self.event_tree.tag_configure("ALARM", foreground=RED)
        self.event_tree.tag_configure("WARN", foreground=YELLOW)

        controls = self.panel(bottom)
        controls.grid(row=0, column=1, sticky="nsew", padx=(8, 0))
        tk.Label(controls, text="监测操作", bg=PANEL, fg=TEXT,
                 font=("Microsoft YaHei UI", 11, "bold")).pack(anchor="w", padx=18, pady=(12, 8))
        actions = tk.Frame(controls, bg=PANEL)
        actions.pack(fill="x", padx=18)
        actions.columnconfigure((0, 1), weight=1)
        ttk.Button(actions, text="立即读取", style="Dark.TButton", command=self.request_status).grid(row=0, column=0, sticky="ew", padx=(0, 5), pady=4)
        self.pause_button = ttk.Button(actions, text="暂停曲线", style="Dark.TButton", command=self.toggle_chart)
        self.pause_button.grid(row=0, column=1, sticky="ew", padx=(5, 0), pady=4)
        self.record_button = ttk.Button(actions, text="开始记录 CSV", style="Dark.TButton", command=self.toggle_recording)
        self.record_button.grid(row=1, column=0, sticky="ew", padx=(0, 5), pady=4)
        ttk.Button(actions, text="导出事件日志", style="Dark.TButton", command=self.export_events).grid(row=1, column=1, sticky="ew", padx=(5, 0), pady=4)
        self.sample_label = tk.Label(controls, text="采样 0 条 · 自动读取 2 Hz", bg=PANEL, fg=CYAN,
                                    font=("Microsoft YaHei UI", 9))
        self.sample_label.pack(anchor="w", padx=18, pady=(10, 4))
        tk.Label(controls, text="光照：暗 <160 / 恢复 >320；声音：高 >700 / 低 <350。\n报警状态以 A 板判定为准，保留连续确认与冷却逻辑。\n串口只读监测，不改变板端功能。",
                 bg=PANEL, fg=MUTED, justify="left", wraplength=410,
                 font=("Microsoft YaHei UI", 9)).pack(anchor="w", padx=18, pady=(0, 10))

    def refresh_ports(self):
        try:
            ports = self.serial.list_ports()
        except Exception as exc:
            self.log("ERROR", f"端口枚举失败：{exc}")
            return
        self.port_combo["values"] = ports
        if ports and self.port_var.get() not in ports:
            self.port_var.set(ports[0])
        if not ports:
            self.port_var.set("")

    def toggle_connection(self):
        if self.serial.connected:
            self.generation += 1
            self.serial.close()
            self.show_unavailable("设备已断开")
            self.connection_label.configure(text="● 未连接", fg=MUTED)
            self.connect_button.configure(text="连接 A 板")
            self.log("INFO", "已断开 A 板串口")
            return
        if not self.port_var.get():
            messagebox.showwarning("应急系统", "没有发现串口，请连接 A 板后刷新端口。")
            return
        try:
            self.serial.open(self.port_var.get(), int(self.baud_var.get()))
        except Exception as exc:
            messagebox.showerror("串口连接失败", str(exc))
            return
        self.generation += 1
        self.last_status = None
        self.chart.samples.clear()
        self.chart.redraw()
        self.show_unavailable("串口已打开，等待有效数据")
        self.connection_label.configure(text=f"● 等待数据 {self.port_var.get()}", fg=YELLOW)
        try:
            self.settings_path.write_text(json.dumps({"port": self.port_var.get()}), encoding="utf-8")
        except OSError as exc:
            self.log("WARN", f"端口偏好未保存：{exc}")
        self.connect_button.configure(text="断开连接")
        self.log("INFO", f"已连接 A 板：{self.port_var.get()} @ {self.baud_var.get()}")

    def poll_once(self):
        if self.serial.connected:
            self.request_status(silent=True)
        self.after(500, self.poll_once)

    def poll_worker(self, generation):
        try:
            status = self.serial.poll_status()
            if status is not None:
                self.events.put(("status", (generation, status)))
            else:
                self.events.put(("timeout", generation))
        except Exception as exc:
            self.events.put(("error", f"读取状态失败：{exc}"))
        finally:
            self.events.put(("poll_done", generation))

    def request_status(self, silent=False):
        if self.serial.connected and not self.polling:
            self.polling = True
            threading.Thread(target=self.poll_worker, args=(self.generation,), daemon=True).start()
        elif not self.serial.connected and not silent:
            self.log("WARN", "读取状态前请先连接 A 板")

    def _enqueue_error(self, message):
        self.events.put(("error", message))

    def drain_events(self):
        try:
            while True:
                kind, payload = self.events.get_nowait()
                if kind == "status":
                    generation, status = payload
                    if generation == self.generation and self.serial.connected: self.update_status(status)
                elif kind == "poll_done":
                    self.polling = False
                elif kind == "timeout":
                    if payload == self.generation and self.serial.connected and not self.stale:
                        self.log("WARN", "设备响应超时，正在继续读取")
                        self.show_unavailable("响应超时，等待重新收到数据")
                else:
                    self.log("ERROR", payload)
        except queue.Empty:
            pass
        if not self.serial.connected:
            self.connect_button.configure(text="连接 A 板")
            self.connection_label.configure(text="● 未连接", fg=MUTED)
            if not self.stale: self.show_unavailable("串口已断开")
        elif self.last_status and time.time() - self.last_status.received_at > 3:
            if not self.stale: self.show_unavailable("数据已过期，请检查连接")
        self.after(100, self.drain_events)

    def show_unavailable(self, reason):
        self.stale = True
        self.alarm_value.configure(text="等待有效数据", fg=MUTED)
        self.alarm_detail.configure(text=reason, fg=MUTED)
        self.alarm_bar.configure(bg=LINE)
        self.light_gauge.set_value(None, "无实时数据")
        self.sound_gauge.set_value(None, "无实时数据")
        if self.serial.connected: self.connection_label.configure(text="● 等待数据", fg=YELLOW)

    def update_status(self, status: BoardStatus):
        previous = self.last_status
        self.last_status = status
        self.history.append(status)
        self.history = self.history[-600:]
        self.stale = False
        self.connection_label.configure(text=f"● 在线 {self.port_var.get()}", fg=GREEN)
        self.total_samples += 1
        row = self.make_row(status)
        self.csv_rows.append(row)
        self.sample_label.configure(text=f"累计 {self.total_samples:,} 条 · 缓存 {len(self.csv_rows):,} 条 · 2 Hz")
        if self._record_writer:
            try:
                self._record_writer.writerow(row)
                self._record_handle.flush()
            except OSError as exc:
                self.stop_recording()
                self.log("ERROR", f"记录文件写入失败：{exc}")
        self.light_gauge.set_value(status.light_raw if status.light_online else None,
                                   "传感器在线 · 原始值 0–65535" if status.light_online else "光照传感器离线")
        self.sound_gauge.set_value(status.sound_level, "ADC 峰峰值 0–4095 · 非分贝")
        if status.collision_alarm:
            title, detail, color = "车辆碰撞报警", "前方发生车辆碰撞，保持原碰撞提示界面", RED
        elif status.sound_alarm:
            title, detail, color = "声音超阈值", f"声音幅度 {status.sound_level}，已进入声音提示场景", YELLOW
        elif not status.light_online:
            title, detail, color = "光照传感器离线", "声音仍在监测，请检查光照传感器连接", YELLOW
        elif status.error_code:
            title, detail, color = "设备状态异常", f"A 板错误码 0x{status.error_code:02X}，请查看设备快照", YELLOW
        elif status.dark:
            title, detail, color = "环境光照不足", "光照传感器在线，系统正在提高画面亮度", CYAN
        else:
            title, detail, color = "系统正常", "A 板当前无碰撞或声音报警", GREEN
        self.alarm_value.configure(text=title, fg=color)
        self.alarm_detail.configure(text=detail, fg=color if status.collision_alarm or status.sound_alarm else MUTED)
        self.alarm_bar.configure(bg=color)
        if not self.chart_paused:
            self.chart.append(status.light_raw if status.light_online else None, status.sound_level, status.received_at)
        self.write_snapshot(status)
        for attr, label in (("collision_alarm", "车辆碰撞报警"), ("sound_alarm", "声音阈值报警"),
                            ("dark", "环境光照不足"), ("light_online", "光照传感器在线")):
            active = getattr(status, attr)
            if (previous and active != getattr(previous, attr)) or (previous is None and active and "alarm" in attr):
                self.log("ALARM" if active and "alarm" in attr else "INFO", f"{label}：{'是' if active else '否'}")
        if status.error_code and (not previous or status.error_code != previous.error_code):
            self.log("WARN", f"A 板错误码 0x{status.error_code:02X}")

    @staticmethod
    def make_row(status):
        return {"时间": datetime.fromtimestamp(status.received_at).isoformat(timespec="milliseconds"),
                "光照原始值": status.light_raw, "光照在线": int(status.light_online),
                "声音幅度": status.sound_level, "光照不足": int(status.dark),
                "声音报警": int(status.sound_alarm), "碰撞报警": int(status.collision_alarm),
                "画面": status.picture + 1, "显示就绪": int(status.display_ready),
                "状态码": status.state_code, "错误码": status.error_code, "亮度": status.brightness,
                "UART错误": status.uart_errors, "协议版本": status.protocol}

    def write_snapshot(self, status):
        lines = [f"光照原始值     {status.light_raw:>5}   在线：{'是' if status.light_online else '否'}",
                 f"声音幅度       {status.sound_level:>5}   高阈值：700",
                 f"光照不足       {'是' if status.dark else '否'}",
                 f"当前画面       PIC{status.picture + 1}    显示：{'就绪' if status.display_ready else '启动中'}",
                 f"状态码         0x{status.state_code:02X}   错误码：0x{status.error_code:02X}",
                 f"亮度偏移       {status.brightness:>5}   音量：{status.volume}",
                 f"UART 错误      {status.uart_errors}   协议：v{status.protocol}",
                 f"最后更新       {datetime.fromtimestamp(status.received_at):%H:%M:%S}"]
        self.snapshot_text.configure(state="normal")
        self.snapshot_text.delete("1.0", "end")
        self.snapshot_text.insert("1.0", chr(10).join(lines))
        self.snapshot_text.configure(state="disabled")

    def toggle_chart(self):
        self.chart_paused = not self.chart_paused
        self.pause_button.configure(text="继续曲线" if self.chart_paused else "暂停曲线")
        if not self.chart_paused:
            self.chart.samples.clear()
            self.chart.redraw()
        self.log("INFO", "曲线已暂停，报警监测和记录继续" if self.chart_paused else "曲线已继续")

    def toggle_recording(self):
        if self._record_handle:
            self.stop_recording()
            return
        target = filedialog.asksaveasfilename(title="记录实时数据", defaultextension=".csv",
            filetypes=(("CSV 文件", "*.csv"),), initialfile=f"应急系统_连续记录_{datetime.now():%Y%m%d_%H%M%S}.csv")
        if not target: return
        try:
            handle = open(target, "w", newline="", encoding="utf-8-sig")
            writer = csv.DictWriter(handle, fieldnames=list(self.make_row(BoardStatus(received_at=time.time()))))
            writer.writeheader()
            handle.flush()
        except OSError as exc:
            if 'handle' in locals(): handle.close()
            messagebox.showerror("记录失败", str(exc))
            return
        self._record_handle, self._record_writer = handle, writer
        self.record_button.configure(text="停止记录 ●")
        self.log("INFO", f"开始记录：{Path(target).name}")

    def stop_recording(self):
        if self._record_handle:
            try: self._record_handle.close()
            except OSError: pass
        self._record_handle = self._record_writer = None
        self.record_button.configure(text="开始记录 CSV")
        self.log("INFO", "实时文件记录已停止")

    def export_events(self):
        if not self.event_rows: return
        target = filedialog.asksaveasfilename(title="导出事件日志", defaultextension=".csv",
            filetypes=(("CSV 文件", "*.csv"),), initialfile=f"应急系统_事件_{datetime.now():%Y%m%d_%H%M%S}.csv")
        if not target: return
        try:
            with open(target, "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.writer(handle)
                writer.writerow(("时间", "级别", "信息"))
                writer.writerows(self.event_rows)
        except OSError as exc:
            messagebox.showerror("导出失败", str(exc))
            return
        self.log("INFO", f"事件日志已导出：{Path(target).name}")

    def log(self, level, message):
        self.event_rows.append((datetime.now().isoformat(timespec="seconds"), level, message))
        self.event_tree.insert("", 0, values=(datetime.now().strftime("%H:%M:%S"), level, message), tags=(level,))
        items = self.event_tree.get_children()
        if len(items) > 100:
            self.event_tree.delete(items[-1])

    def clear_events(self):
        self.event_rows.clear()
        for item in self.event_tree.get_children():
            self.event_tree.delete(item)

    def export_csv(self):
        if not self.csv_rows:
            messagebox.showinfo("应急系统", "还没有可导出的采样数据。")
            return
        target = filedialog.asksaveasfilename(title="导出监测记录", defaultextension=".csv",
                                              filetypes=(("CSV 文件", "*.csv"), ("所有文件", "*.*")),
                                              initialfile=f"应急系统_{datetime.now():%Y%m%d_%H%M%S}.csv")
        if not target:
            return
        try:
            with open(target, "w", newline="", encoding="utf-8-sig") as handle:
                writer = csv.DictWriter(handle, fieldnames=list(self.csv_rows[0]))
                writer.writeheader()
                writer.writerows(self.csv_rows)
        except OSError as exc:
            messagebox.showerror("导出失败", str(exc))
            return
        self.log("INFO", f"监测记录已导出：{Path(target).name}")

    def on_close(self):
        self.generation += 1
        self.stop_recording()
        self.serial.close()
        self.destroy()


if __name__ == "__main__":
    # Keep Windows from stretching the UI bitmap on high-DPI displays.
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except (AttributeError, OSError):
        pass
    EmergencySystem().mainloop()
